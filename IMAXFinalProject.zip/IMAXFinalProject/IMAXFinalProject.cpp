#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>

using namespace std;

// Constants for tax rate, max tickets, and seating dimensions
const double TAX_RATE = 0.07;
const int MAX_TICKETS = 30;
const int ROWS = 5;   // Number of rows in the seating layout
const int COLS = 6;   // Number of columns in the seating layout

// Struct to store ordered items
struct OrderItem {
    string name;
    int quantity;
    double price;
    double total;
};

// Function declarations
void displayMenu();
void displaySubMenu(int choice, double& price, bool& butter, string& sizeDescription);
void getQuantity(int& quantity);
void addToOrder(const string& itemName, double price, int quantity, double& total, vector<OrderItem>& orders, bool butter, const string& sizeDescription);
void displayMovieMenu(int availableTickets[]);
void purchaseTickets(int availableTickets[], double& total, vector<OrderItem>& orders);
void displaySeatingChart(char seats[ROWS][COLS]);
void selectSeats(char seats[ROWS][COLS], int numTickets);
void initializeSeatingChart(char seats[ROWS][COLS]);
void clearScreen();
void printReceipt(const vector<OrderItem>& orders, double total);
void printTicketToFile(const string& filename, int movieChoice, double total, char seats[ROWS][COLS], const vector<OrderItem>& orders);

int main() {
    int choice, quantity;
    double total = 0.0;
    char continueOrder;
    string itemName;
    double itemPrice;
    vector<OrderItem> orders;  // Store the customer's order items
    srand(static_cast<unsigned>(time(0)));

    // Initialize available tickets
    int availableTickets[5];
    for (int i = 0; i < 5; i++) {
        availableTickets[i] = rand() % MAX_TICKETS + 1;
    }

    // Initialize seating chart
    char seats[ROWS][COLS];
    initializeSeatingChart(seats);

    do {
        clearScreen();
        cout << "Welcome to the Blue Dragon IMAX Theatre!\n"
            << "Do you want to: \n"
            << "1. Purchase Tickets \n2. Order Concessions \n3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            purchaseTickets(availableTickets, total, orders);

            // Display and select seats
            int numTickets;
            cout << "Enter the number of tickets you want to purchase: ";
            cin >> numTickets;

            if (numTickets <= MAX_TICKETS) {
                displaySeatingChart(seats); // Show current seating layout
                selectSeats(seats, numTickets); // Select seats

                // Print ticket summary to file
                printTicketToFile("ticket_summary.txt", choice, total, seats, orders);
            }
            else {
                cout << "We don't have that many seats available. Sucks....." << endl;
            }
        }
        else if (choice == 2) {
            // Concessions ordering
            do {
                clearScreen();
                displayMenu();
                cin >> choice;

                if (choice == 5) {
                    break;
                }

                bool butter = false; // Variable to store butter preference for popcorn
                string sizeDescription = ""; // Description for drink size
                displaySubMenu(choice, itemPrice, butter, sizeDescription);
                getQuantity(quantity);
                addToOrder(itemName, itemPrice, quantity, total, orders, butter, sizeDescription); // Pass butter and sizeDescription to addToOrder

                switch (choice) {
                case 1: itemName = "Popcorn"; break;
                case 2: itemName = "Candy"; break;
                case 3: itemName = "Nachos"; break;
                case 4: itemName = "Drink"; break;
                default: itemName = "Unknown"; break;
                }

                cout << "Do you want to continue ordering? (y/n): ";
                cin >> continueOrder;

            } while (continueOrder == 'y' || continueOrder == 'Y');
        }
        else if (choice == 3) {
            break;
        }

    } while (true);

    // Display receipt
    printReceipt(orders, total);

    return 0;
}

// Function to display menu
void displayMenu() {
    cout << "\nConcessions Menu:\n";
    cout << "1. Popcorn - $10.95\n";
    cout << "2. Candy - $8.99\n";
    cout << "3. Nachos - $7.95\n";
    cout << "4. Drink - Small $6.69, Medium $7.69, Large $8.69\n";
    cout << "5. Exit\n";
    cout << "Enter your choice: ";
}

// Updated displaySubMenu function to include butter and size options
void displaySubMenu(int choice, double& price, bool& butter, string& sizeDescription) {
    switch (choice) {
    case 1:  // Popcorn options
        cout << "Would you like butter on your popcorn? (y/n): ";
        char butterChoice;
        cin >> butterChoice;
        price = 10.95;  // Base price for popcorn
        butter = (butterChoice == 'y' || butterChoice == 'Y');
        if (butter) {
            cout << "Butter added to popcorn.\n";
            price += 0.50;  // Additional charge for butter
        }
        break;
    case 2:  // Candy
        price = 8.99;
        break;
    case 3:  // Nachos
        price = 7.95;
        break;
    case 4:  // Drink sizes
        cout << "What size drink? (1 - Small, 2 - Medium, 3 - Large): ";
        int size;
        cin >> size;
        if (size == 1) {
            price = 6.69;
            sizeDescription = "Small";
        }
        else if (size == 2) {
            price = 7.69;
            sizeDescription = "Medium";
        }
        else {
            price = 8.69;
            sizeDescription = "Large";
        }
        break;
    default:
        cout << "Invalid choice.\n";
        break;
    }
}

// Function to get quantity of an item
void getQuantity(int& quantity) {
    cout << "Enter quantity: ";
    cin >> quantity;
}

// Function to initialize seating chart with random reservations
void initializeSeatingChart(char seats[ROWS][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            seats[i][j] = (rand() % 2 == 0) ? 'O' : 'X';
        }
    }
}

// Function to display seating chart
void displaySeatingChart(char seats[ROWS][COLS]) {
    cout << "\nSeating Chart:\n";
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            cout << seats[i][j] << ' ';
        }
        cout << endl;
    }
}

// Function to clear the screen (platform-specific)
void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Function to select seats
void selectSeats(char seats[ROWS][COLS], int numTickets) {
    int row, col;
    for (int i = 0; i < numTickets; i++) {
        cout << "Select seat " << (i + 1) << " (enter row and column): ";
        cin >> row >> col;

        while (seats[row][col] == 'X' || row >= ROWS || col >= COLS) {
            cout << "Seat is unavailable. Please choose a different seat.\n";
            cout << "Select seat " << (i + 1) << " (enter row and column): ";
            cin >> row >> col;
        }

        seats[row][col] = 'X';
    }
    cout << "Seats reserved successfully!\n";
}

// Function to add an item to the order list
void addToOrder(const string& itemName, double price, int quantity, double& total, vector<OrderItem>& orders, bool butter, const string& sizeDescription) {
    string finalItemName = itemName;
    if (butter && itemName == "Popcorn") {
        finalItemName += " with Butter";
    }
    if (!sizeDescription.empty() && itemName == "Drink") {
        finalItemName += " (" + sizeDescription + ")";
    }

    double itemTotal = price * quantity;
    total += itemTotal;
    orders.push_back({ finalItemName, quantity, price, itemTotal });

    cout << "\n-------------------------------------------------\n";
    cout << "Added " << quantity << " " << finalItemName << "(s) to your order.\n";
    cout << "Total so far: $" << fixed << setprecision(2) << total << endl;
    cout << "-------------------------------------------------\n";
}

// Function to display the movie menu with available ticket counts
void displayMovieMenu(int availableTickets[]) {
    cout << "\nAvailable Movies and Ticket Prices:\n";
    cout << "-------------------------------------------------\n";
    cout << "1 - Attack of the Killer Tomatoes ... PG (" << availableTickets[0] << " seats left)\n";
    cout << "2 - Rocky Horror Picture Show ....... R (" << availableTickets[1] << " seats left)\n";
    cout << "3 - Pink Floyd � The Wall ........... R (" << availableTickets[2] << " seats left)\n";
    cout << "4 - Monty Python and the Holy Grail . PG (" << availableTickets[3] << " seats left)\n";
    cout << "5 - Young Frankenstein .............. PG (" << availableTickets[4] << " seats left)\n";
    cout << "-------------------------------------------------\n";
    cout << "Adult $15 | Child $10 | Senior $7 | Matinee $5\n";
    cout << "0 - End selection\n";
}

// Function to handle ticket purchase
void purchaseTickets(int availableTickets[], double& total, vector<OrderItem>& orders) {
    int movieChoice, ageGroup, quantity;
    double ticketPrice;

    displayMovieMenu(availableTickets);
    cout << "Choose a movie (1-5) or 0 to finish: ";
    cin >> movieChoice;

    if (movieChoice == 0) return;

    if (movieChoice < 1 || movieChoice > 5) {
        cout << "Invalid movie selection." << endl;
        return;
    }

    // Ticket price by age group
    cout << "Select age group: 1 - Adult, 2 - Child, 3 - Senior, 4 - Matinee: ";
    cin >> ageGroup;

    switch (ageGroup) {
    case 1: ticketPrice = 15.0; break;
    case 2: ticketPrice = 10.0; break;
    case 3: ticketPrice = 7.0; break;
    case 4: ticketPrice = 5.0; break;
    default:
        cout << "Invalid age group." << endl;
        return;
    }

    cout << "How many tickets? ";
    cin >> quantity;

    if (quantity > availableTickets[movieChoice - 1]) {
        cout << "Not enough seats available." << endl;
        return;
    }

    availableTickets[movieChoice - 1] -= quantity;
    addToOrder("Movie Ticket", ticketPrice, quantity, total, orders, false, "");
}

// Function to print a detailed receipt with date
void printReceipt(const vector<OrderItem>& orders, double total) {
    time_t now = time(0);
    tm localTime;
    localtime_s(&localTime, &now);  // Using safe localtime_s function

    cout << "\n-------------------------------------------------\n";
    cout << "Receipt Date: " << (localTime.tm_mon + 1) << "/"
        << localTime.tm_mday << "/" << (localTime.tm_year + 1900) << endl;
    cout << "Itemized Receipt:\n";
    cout << "-------------------------------------------------\n";
    cout << left << setw(20) << "Item" << setw(10) << "Qty" << setw(10) << "Price" << setw(10) << "Total" << endl;
    for (const auto& item : orders) {
        cout << left << setw(20) << item.name << setw(10) << item.quantity << setw(10) << fixed << setprecision(2) << item.price << setw(10) << item.total << endl;
    }

    double tax = total * TAX_RATE;
    double grandTotal = total + tax;
    cout << "\nSubtotal: $" << fixed << setprecision(2) << total << endl;
    cout << "Tax (NC): $" << tax << endl;
    cout << "Grand Total: $" << grandTotal << endl;
    cout << "-------------------------------------------------\n";
}

// Function to print ticket summary to a file, including the order details
void printTicketToFile(const string& filename, int movieChoice, double total, char seats[ROWS][COLS], const vector<OrderItem>& orders) {
    ofstream ticketFile(filename);
    if (ticketFile.is_open()) {
        ticketFile << "Ticket Summary:\n";
        ticketFile << "Movie Selected: " << movieChoice << endl;
        ticketFile << "Seats Reserved:\n";
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                ticketFile << seats[i][j] << ' ';
            }
            ticketFile << endl;
        }

        ticketFile << "\nItemized Receipt:\n";
        ticketFile << left << setw(20) << "Item" << setw(10) << "Qty" << setw(10) << "Price" << setw(10) << "Total" << endl;
        for (const auto& item : orders) {
            ticketFile << left << setw(20) << item.name << setw(10) << item.quantity << setw(10) << item.price << setw(10) << item.total << endl;
        }

        double tax = total * TAX_RATE;
        double grandTotal = total + tax;
        ticketFile << "\nSubtotal: $" << total << endl;
        ticketFile << "Tax (NC): $" << tax << endl;
        ticketFile << "Grand Total: $" << grandTotal << endl;
        ticketFile.close();
        cout << "Ticket printed to " << filename << endl;
    }
    else {
        cout << "Error opening file." << endl;
    }
}
